'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Contact() {
  const [formData, setFormData] = useState({
    nom: '',
    email: '',
    telephone: '',
    service: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Validation
    if (!formData.nom || !formData.email || !formData.message) {
      setSubmitStatus('Veuillez remplir tous les champs obligatoires.');
      setIsSubmitting(false);
      return;
    }

    if (formData.message.length > 500) {
      setSubmitStatus('Le message ne peut pas dépasser 500 caractères.');
      setIsSubmitting(false);
      return;
    }

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams(formData).toString()
      });

      if (response.ok) {
        setSubmitStatus('Votre message a été envoyé avec succès ! Nous vous contacterons bientôt.');
        setFormData({
          nom: '',
          email: '',
          telephone: '',
          service: '',
          message: ''
        });
      } else {
        setSubmitStatus('Une erreur est survenue. Veuillez réessayer.');
      }
    } catch (error) {
      setSubmitStatus('Une erreur est survenue. Veuillez réessayer.');
    }

    setIsSubmitting(false);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <Link href="/">
                <img 
                  src="https://static.readdy.ai/image/05dc9145483e3f0acd1651ba18bf1f9f/cd52e9b51327bdafe6e482994b87c893.jfif" 
                  alt="Innovatech Building Group" 
                  className="h-12 w-auto cursor-pointer"
                />
              </Link>
            </div>

            {/* Menu */}
            <div className="hidden md:flex space-x-8">
              <Link href="/" className="text-gray-600 hover:text-red-600 font-medium">Accueil</Link>
              <Link href="/services" className="text-gray-600 hover:text-red-600 font-medium">Services</Link>
              <Link href="/realisations" className="text-gray-600 hover:text-red-600 font-medium">Réalisations</Link>
              <Link href="/contact" className="text-red-900 hover:text-red-600 font-medium">Contact</Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gray-50 py-20">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Contactez-nous</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Discutons de votre projet et donnons vie à vos idées ensemble
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-16">
            {/* Contact Info */}
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-8">Nos Coordonnées</h2>

              <div className="space-y-8">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                    <i className="ri-phone-line text-xl text-red-600"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Téléphone</h3>
                    <p className="text-gray-600">+237 656 013 365</p>
                    <p className="text-gray-600">+237 673 340 009</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                    <i className="ri-mail-line text-xl text-red-600"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Email</h3>
                    <p className="text-gray-600">innovatechbuildingg@gmail.com</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                    <i className="ri-map-pin-line text-xl text-red-600"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Adresse</h3>
                    <p className="text-gray-600">Direction Générale<br />Yaoundé, Cameroun</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                    <i className="ri-time-line text-xl text-red-600"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Horaires</h3>
                    <p className="text-gray-600">Lundi - Vendredi: 8h00 - 18h00</p>
                    <p className="text-gray-600">Samedi: 9h00 - 14h00</p>
                  </div>
                </div>
              </div>

              {/* Map */}
              <div className="mt-12">
                <h3 className="text-xl font-bold text-gray-900 mb-4">Notre Localisation</h3>
                <div className="rounded-lg overflow-hidden shadow-sm">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d127087.8938339832!2d11.432691!3d3.8667!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x108bcf1a8ea7a35f%3A0xc9d5bba8b1b80e2a!2sYaound%C3%A9%2C%20Cameroon!5e0!3m2!1sen!2sus!4v1703845234567!5m2!1sen!2sus"
                    width="100%"
                    height="300"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                  ></iframe>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div>
              <div className="bg-gray-50 p-8 rounded-xl">
                <h2 className="text-3xl font-bold text-gray-900 mb-8">Demande de Devis</h2>

                <form id="contact-form" onSubmit={handleSubmit}>
                  <div className="grid md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label htmlFor="nom" className="block text-sm font-medium text-gray-700 mb-2">
                        Nom complet *
                      </label>
                      <input
                        type="text"
                        id="nom"
                        name="nom"
                        value={formData.nom}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 text-sm"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                        Email *
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 text-sm"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label htmlFor="telephone" className="block text-sm font-medium text-gray-700 mb-2">
                        Téléphone
                      </label>
                      <input
                        type="tel"
                        id="telephone"
                        name="telephone"
                        value={formData.telephone}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 text-sm"
                      />
                    </div>
                    <div>
                      <label htmlFor="service" className="block text-sm font-medium text-gray-700 mb-2">
                        Service souhaité
                      </label>
                      <select
                        id="service"
                        name="service"
                        value={formData.service}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 pr-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 text-sm appearance-none bg-white"
                      >
                        <option value="">Sélectionnez un service</option>
                        <option value="topographie">Topographie & Topométrie</option>
                        <option value="conception">Conception</option>
                        <option value="devis">Devis</option>
                        <option value="realisation">Réalisation</option>
                        <option value="design">Design d\'Intérieur</option>
                        <option value="autre">Autre</option>
                      </select>
                    </div>
                  </div>

                  <div className="mb-6">
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                      Message *
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      rows={6}
                      value={formData.message}
                      onChange={handleInputChange}
                      maxLength={500}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 text-sm resize-none"
                      placeholder="Décrivez votre projet en détail..."
                      required
                    ></textarea>
                    <p className="text-sm text-gray-500 mt-1">
                      {formData.message.length}/500 caractères
                    </p>
                  </div>

                  {submitStatus && (
                    <div className={`mb-6 p-4 rounded-lg ${
                      submitStatus.includes('succès') 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-red-100 text-red-700'
                    }`}>
                      {submitStatus}
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-red-600 hover:bg-red-700 disabled:bg-red-400 text-white font-semibold py-3 px-6 rounded-lg whitespace-nowrap cursor-pointer transition-colors"
                  >
                    {isSubmitting ? 'Envoi en cours...' : 'Envoyer le message'}
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-12">
            <div>
              <img 
                src="https://static.readdy.ai/image/05dc9145483e3f0acd1651ba18bf1f9f/cd52e9b51327bdafe6e482994b87c893.jfif" 
                alt="Innovatech Building Group" 
                className="h-16 w-auto mb-4"
              />
              <p className="text-gray-400 mb-4">
                Bâtissons nos rêves - Notre engagement, votre satisfaction
              </p>
            </div>

            <div>
              <h3 className="text-lg font-bold mb-6">Contact</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <i className="ri-phone-line text-red-500"></i>
                  <span>+237 656 013 365</span>
                </div>
                <div className="flex items-center gap-3">
                  <i className="ri-phone-line text-red-500"></i>
                  <span>+237 673 340 009</span>
                </div>
                <div className="flex items-center gap-3">
                  <i className="ri-mail-line text-red-500"></i>
                  <span>innovatechbuildingg@gmail.com</span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-bold mb-6">Services</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Topographie & Topométrie</li>
                <li>Conception</li>
                <li>Devis</li>
                <li>Réalisation</li>
                <li>Design d\'Intérieur</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Innovatech Building Group. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
