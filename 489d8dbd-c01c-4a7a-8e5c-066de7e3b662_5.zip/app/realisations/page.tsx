
'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';

export default function Realisations() {
  const [selectedProject, setSelectedProject] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);

  // Images pour le carrousel
  const heroImages = [
    {
      url: "https://readdy.ai/api/search-image?query=Modern%20residential%20complex%20with%20beautiful%20gardens%20and%20landscaping%20in%20Yaound%C3%A9%20Cameroon%2C%20contemporary%20apartment%20buildings%20with%20balconies%2C%20well-maintained%20green%20spaces%2C%20parking%20areas%2C%20African%20architectural%20style%2C%20bright%20daylight%2C%20professional%20real%20estate%20photography&width=1920&height=600&seq=carousel-1&orientation=landscape",
      title: "Complexes Résidentiels"
    },
    {
      url: "https://readdy.ai/api/search-image?query=Modern%20shopping%20center%20in%20Cameroon%20with%20glass%20facades%2C%20contemporary%20commercial%20architecture%2C%20multiple%20levels%2C%20wide%20entrances%2C%20professional%20lighting%2C%20busy%20commercial%20area%2C%20African%20urban%20setting%2C%20high-quality%20architectural%20photography&width=1920&height=600&seq=carousel-2&orientation=landscape",
      title: "Centres Commerciaux"
    },
    {
      url: "https://readdy.ai/api/search-image?query=Modern%20corporate%20office%20building%20with%20glass%20and%20steel%20construction%2C%20contemporary%20business%20architecture%20in%20Yaound%C3%A9%2C%20professional%20office%20complex%2C%20clean%20lines%20and%20modern%20design%2C%20African%20urban%20landscape%2C%20architectural%20photography&width=1920&height=600&seq=carousel-3&orientation=landscape",
      title: "Bureaux Modernes"
    },
    {
      url: "https://readdy.ai/api/search-image?query=Luxury%20family%20villa%20with%20swimming%20pool%20and%20landscaped%20garden%20in%20Bastos%20Yaound%C3%A9%2C%20modern%20residential%20architecture%2C%20elegant%20design%2C%20tropical%20landscaping%2C%20African%20luxury%20home%2C%20high-end%20residential%20construction%2C%20professional%20architecture%20photography&width=1920&height=600&seq=carousel-4&orientation=landscape",
      title: "Villas de Luxe"
    },
    {
      url: "https://readdy.ai/api/search-image?query=Modern%20primary%20school%20building%20in%20Cameroon%20with%20colorful%20architecture%2C%20educational%20facility%20with%20multiple%20classrooms%2C%20children-friendly%20design%2C%20school%20playground%2C%20contemporary%20African%20educational%20architecture%2C%20bright%20and%20welcoming%20atmosphere&width=1920&height=600&seq=carousel-5&orientation=landscape",
      title: "Établissements Éducatifs"
    }
  ];

  // Défilement automatique du carrousel
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroImages.length);
    }, 4000); // Change d'image toutes les 4 secondes

    return () => clearInterval(interval);
  }, [heroImages.length]);

  const goToSlide = (index) => {
    setCurrentSlide(index);
  };

  const projets = [
    {
      id: 1,
      titre: "Complexe Résidentiel Les Jardins",
      categorie: "Résidentiel",
      description: "Construction d'un complexe résidentiel moderne de 48 appartements avec espaces verts et parking souterrain.",
      descriptionComplete: "Ce projet ambitieux comprend la construction d'un complexe résidentiel haut de gamme situé dans un quartier prisé de Yaoundé. Le complexe se compose de 48 appartements répartis sur 4 bâtiments, avec une architecture moderne et élégante. Les espaces verts paysagers occupent 30% de la superficie totale, offrant un cadre de vie exceptionnel aux résidents.",
      caracteristiques: [
        "48 appartements (T2, T3, T4)",
        "4 bâtiments de 3 étages",
        "Parking souterrain de 60 places",
        "Espaces verts paysagers",
        "Salle de sport commune",
        "Aire de jeux pour enfants",
        "Système de sécurité 24h/24"
      ],
      image: "https://readdy.ai/api/search-image?query=Modern%20residential%20complex%20with%20beautiful%20gardens%20and%20landscaping%20in%20Yaound%C3%A9%20Cameroon%2C%20contemporary%20apartment%20buildings%20with%20balconies%2C%20well-maintained%20green%20spaces%2C%20parking%20areas%2C%20African%20architectural%20style%2C%20bright%20daylight%2C%20professional%20real%20estate%20photography&width=600&height=400&seq=project-1&orientation=landscape",
      annee: "2023",
      superficie: "3,200 m²",
      duree: "18 mois",
      client: "Société Immobilière Camerounaise",
      localisation: "Bastos, Yaoundé"
    },
    {
      id: 2,
      titre: "Centre Commercial Mvog-Ada",
      categorie: "Commercial",
      description: "Réalisation d'un centre commercial moderne avec 45 boutiques, restaurants et espaces de loisirs.",
      descriptionComplete: "Ce centre commercial représente un nouveau concept de shopping à Yaoundé, combinant commerce, restauration et divertissement. Avec ses 45 boutiques réparties sur 3 niveaux, il offre une expérience shopping complète dans un environnement climatisé et sécurisé.",
      caracteristiques: [
        "45 boutiques et magasins",
        "6 restaurants et cafés",
        "Cinéma multiplex de 4 salles",
        "Aire de jeux pour enfants",
        "Parking de 200 places",
        "Système de climatisation central",
        "Ascenseurs et escalators"
      ],
      image: "https://readdy.ai/api/search-image?query=Modern%20shopping%20center%20in%20Cameroon%20with%20glass%20facades%2C%20contemporary%20commercial%20architecture%2C%20multiple%20levels%2C%20wide%20entrances%2C%20professional%20lighting%2C%20busy%20commercial%20area%2C%20African%20urban%20setting%2C%20high-quality%20architectural%20photography&width=600&height=400&seq=project-2&orientation=landscape",
      annee: "2022",
      superficie: "5,800 m²",
      duree: "24 mois",
      client: "Groupe Commercial SARL",
      localisation: "Mvog-Ada, Yaoundé"
    },
    {
      id: 3,
      titre: "Siège Social TechCorp",
      categorie: "Bureaux",
      description: "Construction du siège social d'une entreprise technologique avec bureaux modernes et espaces collaboratifs.",
      descriptionComplete: "Ce bâtiment de bureaux moderne reflète l'innovation et la modernité de l'entreprise TechCorp. Conçu selon les standards internationaux, il offre des espaces de travail flexibles et collaboratifs, équipés des dernières technologies.",
      caracteristiques: [
        "Open spaces modulables",
        "Salles de réunion équipées",
        "Espaces de coworking",
        "Cafétéria d'entreprise",
        "Terrasse panoramique",
        "Fibre optique intégrée",
        "Système de ventilation intelligent"
      ],
      image: "https://readdy.ai/api/search-image?query=Modern%20corporate%20office%20building%20with%20glass%20and%20steel%20construction%2C%20contemporary%20business%20architecture%20in%20Yaound%C3%A9%2C%20professional%20office%20complex%2C%20clean%20lines%20and%20modern%20design%2C%20African%20urban%20landscape%2C%20architectural%20photography&width=600&height=400&seq=project-3&orientation=landscape",
      annee: "2023",
      superficie: "2,400 m²",
      duree: "14 mois",
      client: "TechCorp Cameroun",
      localisation: "Centre-ville, Yaoundé"
    },
    {
      id: 4,
      titre: "Villa Familiale Bastos",
      categorie: "Résidentiel",
      description: "Conception et construction d'une villa familiale de luxe avec piscine et jardin paysager.",
      descriptionComplete: "Cette villa de luxe située dans le quartier huppé de Bastos représente l'excellence en matière d'architecture résidentielle. Chaque détail a été pensé pour offrir un cadre de vie exceptionnel à cette famille, alliant confort moderne et élégance traditionnelle.",
      caracteristiques: [
        "5 chambres avec suites",
        "Salon double hauteur",
        "Cuisine américaine équipée",
        "Piscine à débordement",
        "Jardin paysager 800m²",
        "Garage pour 3 véhicules",
        "Système domotique intégré"
      ],
      image: "https://readdy.ai/api/search-image?query=Luxury%20family%20villa%20with%20swimming%20pool%20and%20landscaped%20garden%20in%20Bastos%20Yaound%C3%A9%2C%20modern%20residential%20architecture%2C%20elegant%20design%2C%20tropical%20landscaping%2C%20African%20luxury%20home%2C%20high-end%20residential%20construction%2C%20professional%20architecture%20photography&width=600&height=400&seq=project-4&orientation=landscape",
      annee: "2022",
      superficie: "450 m²",
      duree: "10 mois",
      client: "Famille Mballa",
      localisation: "Bastos, Yaoundé"
    },
    {
      id: 5,
      titre: "École Primaire Nouvelle Génération",
      categorie: "Éducation",
      description: "Construction d'une école primaire moderne avec 12 salles de classe, laboratoire et bibliothèque.",
      descriptionComplete: "Cette école primaire moderne a été conçue pour offrir un environnement d'apprentissage optimal aux enfants. L'architecture colorée et fonctionnelle crée un cadre stimulant pour l'éducation, avec des espaces adaptés à chaque activité pédagogique.",
      caracteristiques: [
        "12 salles de classe climatisées",
        "Laboratoire de sciences",
        "Bibliothèque multimédia",
        "Cantine scolaire",
        "Terrain de sport",
        "Cour de récréation sécurisée",
        "Infirmerie équipée"
      ],
      image: "https://readdy.ai/api/search-image?query=Modern%20primary%20school%20building%20in%20Cameroon%20with%20colorful%20architecture%2C%20educational%20facility%20with%20multiple%20classrooms%2C%20children-friendly%20design%2C%20school%20playground%2C%20contemporary%20African%20educational%20architecture%2C%20bright%20and%20welcoming%20atmosphere&width=600&height=400&seq=project-5&orientation=landscape",
      annee: "2023",
      superficie: "1,800 m²",
      duree: "16 mois",
      client: "Fondation Éducative du Cameroun",
      localisation: "Emana, Yaoundé"
    },
    {
      id: 6,
      titre: "Clinique Médicale Saint-Paul",
      categorie: "Santé",
      description: "Rénovation et extension d'une clinique médicale avec équipements modernes et espaces d'accueil.",
      descriptionComplete: "Ce projet de rénovation et d'extension a permis de moderniser entièrement cette clinique médicale. Les nouveaux aménagements respectent les normes sanitaires les plus strictes tout en créant un environnement rassurant pour les patients.",
      caracteristiques: [
        "15 cabinets de consultation",
        "2 blocs opératoires",
        "Service d'urgences 24h/24",
        "Laboratoire d'analyses",
        "Pharmacie intégrée",
        "Parking patients et staff",
        "Système de stérilisation moderne"
      ],
      image: "https://readdy.ai/api/search-image?query=Modern%20medical%20clinic%20building%20in%20Yaound%C3%A9%20Cameroon%2C%20healthcare%20facility%20with%20clean%20white%20architecture%2C%20medical%20building%20with%20professional%20design%2C%20modern%20hospital%20exterior%2C%20African%20healthcare%20infrastructure%2C%20architectural%20photography&width=600&height=400&seq=project-6&orientation=landscape",
      annee: "2022",
      superficie: "1,200 m²",
      duree: "12 mois",
      client: "Clinique Saint-Paul",
      localisation: "Mfoundi, Yaoundé"
    }
  ];

  const openModal = (projet) => {
    setSelectedProject(projet);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setSelectedProject(null);
    setIsModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <img 
                src="https://static.readdy.ai/image/05dc9145483e3f0acd1651ba18bf1f9f/cd52e9b51327bdafe6e482994b87c893.jfif" 
                alt="Innovatech Building Group" 
                className="h-12 w-auto"
              />
            </div>
            {/* Menu */}
            <div className="hidden md:flex space-x-8">
              <Link href="/" className="text-gray-600 hover:text-red-600 font-medium">Accueil</Link>
              <Link href="/services" className="text-gray-600 hover:text-red-600 font-medium">Services</Link>
              <Link href="/realisations" className="text-gray-900 hover:text-red-600 font-medium">Réalisations</Link>
              <Link href="/contact" className="text-gray-600 hover:text-red-600 font-medium">Contact</Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section avec Carrousel */}
      <section className="relative h-96 overflow-hidden">
        {/* Images du carrousel */}
        <div className="relative w-full h-full">
          {heroImages.map((image, index) => (
            <div
              key={index}
              className={`absolute inset-0 transition-opacity duration-1000 ${
                index === currentSlide ? 'opacity-100' : 'opacity-0'
              }`}
              style={{
                backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('${image.url}')`,
                backgroundSize: 'cover',
                backgroundPosition: 'center'
              }}
            >
              <div className="absolute inset-0 flex items-center">
                <div className="w-full max-w-7xl mx-auto px-4">
                  <div className="text-white">
                    <h1 className="text-5xl font-bold mb-4">Nos Réalisations</h1>
                    <p className="text-xl mb-2">{image.title}</p>
                    <p className="text-lg opacity-90">
                      Plus de 50 projets réalisés avec succès à Yaoundé et environs
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Indicateurs de pagination */}
        <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex space-x-2">
          {heroImages.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`w-3 h-3 rounded-full transition-colors cursor-pointer ${
                index === currentSlide ? 'bg-white' : 'bg-white/50'
              }`}
            />
          ))}
        </div>

        {/* Boutons de navigation */}
        <button
          onClick={() => goToSlide((currentSlide - 1 + heroImages.length) % heroImages.length)}
          className="absolute left-4 top-1/2 transform -translate-y-1/2 w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center text-white transition-colors cursor-pointer"
        >
          <i className="ri-arrow-left-line text-xl"></i>
        </button>
        <button
          onClick={() => goToSlide((currentSlide + 1) % heroImages.length)}
          className="absolute right-4 top-1/2 transform -translate-y-1/2 w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center text-white transition-colors cursor-pointer"
        >
          <i className="ri-arrow-right-line text-xl"></i>
        </button>
      </section>

      {/* Filtres */}
      <section className="py-8 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-center">
            <div className="flex flex-wrap gap-4">
              <button className="bg-red-600 text-white px-6 py-2 rounded-full font-medium whitespace-nowrap cursor-pointer">
                Tous
              </button>
              <button className="bg-white text-gray-700 hover:bg-gray-100 px-6 py-2 rounded-full font-medium border whitespace-nowrap cursor-pointer">
                Résidentiel
              </button>
              <button className="bg-white text-gray-700 hover:bg-gray-100 px-6 py-2 rounded-full font-medium border whitespace-nowrap cursor-pointer">
                Commercial
              </button>
              <button className="bg-white text-gray-700 hover:bg-gray-100 px-6 py-2 rounded-full font-medium border whitespace-nowrap cursor-pointer">
                Bureaux
              </button>
              <button className="bg-white text-gray-700 hover:bg-gray-100 px-6 py-2 rounded-full font-medium border whitespace-nowrap cursor-pointer">
                Éducation
              </button>
              <button className="bg-white text-gray-700 hover:bg-gray-100 px-6 py-2 rounded-full font-medium border whitespace-nowrap cursor-pointer">
                Santé
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Projets Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projets.map((projet) => (
              <div key={projet.id} className="bg-white rounded-xl shadow-sm hover:shadow-lg transition-shadow overflow-hidden">
                <div className="relative">
                  <img 
                    src={projet.image}
                    alt={projet.titre}
                    className="w-full h-48 object-cover object-top"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="bg-red-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                      {projet.categorie}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{projet.titre}</h3>
                  <p className="text-gray-600 mb-4">{projet.description}</p>
                  <div className="space-y-2 text-sm text-gray-500">
                    <div className="flex justify-between">
                      <span>Année :</span>
                      <span className="font-medium">{projet.annee}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Superficie :</span>
                      <span className="font-medium">{projet.superficie}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Durée :</span>
                      <span className="font-medium">{projet.duree}</span>
                    </div>
                  </div>
                  <button 
                    onClick={() => openModal(projet)}
                    className="mt-4 w-full bg-gray-100 hover:bg-red-50 text-gray-700 hover:text-red-600 py-2 rounded-lg font-medium transition-colors whitespace-nowrap cursor-pointer"
                  >
                    Voir les détails
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Modal */}
      {isModalOpen && selectedProject && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-4xl w-full max-h-screen overflow-y-auto">
            <div className="sticky top-0 bg-white border-b p-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-900">{selectedProject.titre}</h2>
                <button 
                  onClick={closeModal}
                  className="w-8 h-8 bg-gray-100 hover:bg-gray-200 rounded-full flex items-center justify-center cursor-pointer"
                >
                  <i className="ri-close-line text-gray-600"></i>
                </button>
              </div>
            </div>
            <div className="p-6">
              <div className="grid lg:grid-cols-2 gap-8">
                <div>
                  <img 
                    src={selectedProject.image}
                    alt={selectedProject.titre}
                    className="w-full h-64 object-cover object-top rounded-lg"
                  />
                  <div className="mt-6 grid grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-1">Client</h4>
                      <p className="text-gray-600">{selectedProject.client}</p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-1">Localisation</h4>
                      <p className="text-gray-600">{selectedProject.localisation}</p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-1">Superficie</h4>
                      <p className="text-gray-600">{selectedProject.superficie}</p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-1">Durée</h4>
                      <p className="text-gray-600">{selectedProject.duree}</p>
                    </div>
                  </div>
                </div>
                <div>
                  <div className="mb-6">
                    <span className="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm font-medium">
                      {selectedProject.categorie}
                    </span>
                    <span className="ml-3 text-gray-500">{selectedProject.annee}</span>
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-3">Description du projet</h3>
                  <p className="text-gray-600 mb-6">{selectedProject.descriptionComplete}</p>
                  <h3 className="text-lg font-bold text-gray-900 mb-3">Caractéristiques principales</h3>
                  <ul className="space-y-2">
                    {selectedProject.caracteristiques.map((carac, idx) => (
                      <li key={idx} className="flex items-center gap-3">
                        <div className="w-2 h-2 bg-red-600 rounded-full"></div>
                        <span className="text-gray-700">{carac}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              <div className="mt-8 pt-6 border-t flex justify-center">
                <Link href="/contact" className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-lg font-semibold whitespace-nowrap cursor-pointer transition-colors">
                  Demander un projet similaire
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Statistiques */}
      <section className="py-16 bg-red-600">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">Nos Chiffres</h2>
            <p className="text-xl text-red-100">L'excellence mesurée en résultats</p>
          </div>
          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-white mb-2">50+</div>
              <div className="text-red-100">Projets Réalisés</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-white mb-2">8</div>
              <div className="text-red-100">Années d'Expérience</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-white mb-2">100%</div>
              <div className="text-red-100">Clients Satisfaits</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-white mb-2">25</div>
              <div className="text-red-100">Experts Qualifiés</div>
            </div>
          </div>
        </div>
      </section>

      {/* Témoignages */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Ce que disent nos clients</h2>
            <p className="text-xl text-gray-600">Leurs témoignages reflètent notre engagement</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="flex items-center mb-4">
                <div className="flex text-yellow-400">
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                </div>
              </div>
              <p className="text-gray-600 mb-4">
                "Innovatech a transformé notre vision en réalité. La qualité de construction et le respect des délais ont dépassé nos attentes."
              </p>
              <div>
                <p className="font-bold text-gray-900">Marie Nguema</p>
                <p className="text-gray-500 text-sm">Directrice, TechCorp</p>
              </div>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="flex items-center mb-4">
                <div className="flex text-yellow-400">
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                </div>
              </div>
              <p className="text-gray-600 mb-4">
                "Une équipe professionnelle et à l'écoute. Notre villa familiale est exactement ce que nous souhaitions."
              </p>
              <div>
                <p className="font-bold text-gray-900">Paul Mbida</p>
                <p className="text-gray-500 text-sm">Propriétaire, Villa Bastos</p>
              </div>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="flex items-center mb-4">
                <div className="flex text-yellow-400">
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                </div>
              </div>
              <p className="text-gray-600 mb-4">
                "Excellent travail sur notre centre commercial. L'expertise technique et la gestion de projet sont remarquables."
              </p>
              <div>
                <p className="font-bold text-gray-900">Jean Atangana</p>
                <p className="text-gray-500 text-sm">Investisseur Immobilier</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Votre projet, notre expertise</h2>
          <p className="text-xl text-gray-600 mb-8">
            Rejoignez nos clients satisfaits et concrétisez vos projets avec Innovatech Building Group
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact" className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-lg font-semibold whitespace-nowrap cursor-pointer transition-colors">
              Demander un Devis
            </Link>
            <Link href="/services" className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-8 py-3 rounded-lg font-semibold whitespace-nowrap cursor-pointer transition-colors">
              Découvrir nos Services
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-12">
            <div>
              <img 
                src="https://static.readdy.ai/image/05dc9145483e3f0acd1651ba18bf1f9f/cd52e9b51327bdafe6e482994b87c893.jfif" 
                alt="Innovatech Building Group" 
                className="h-16 w-auto mb-4"
              />
              <p className="text-gray-400 mb-4">
                Bâtissons nos rêves - Notre engagement, votre satisfaction
              </p>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-6">Contact</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <i className="ri-phone-line text-red-500"></i>
                  <span>+237 656 013 365</span>
                </div>
                <div className="flex items-center gap-3">
                  <i className="ri-phone-line text-red-500"></i>
                  <span>+237 673 340 009</span>
                </div>
                <div className="flex items-center gap-3">
                  <i className="ri-mail-line text-red-500"></i>
                  <span>innovatechbuildingg@gmail.com</span>
                </div>
                <div className="flex items-center gap-3">
                  <i className="ri-map-pin-line text-red-500"></i>
                  <span>Yaoundé, Cameroun</span>
                </div>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-6">Services</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Topographie & Topométrie</li>
                <li>Conception</li>
                <li>Devis</li>
                <li>Réalisation</li>
                <li>Design d'Intérieur</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Innovatech Building Group. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
