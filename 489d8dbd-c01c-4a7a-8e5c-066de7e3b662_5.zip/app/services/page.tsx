'use client';

import Link from 'next/link';

export default function Services() {
  const services = [
    {
      id: 'topographie',
      title: 'Topographie & Topométrie',
      icon: 'ri-compass-3-line',
      description: 'Relevés topographiques précis et études de terrain pour vos projets de construction.',
      details: [
        'Levés topographiques complets',
        'Mesures altimétriques précises',
        'Cartographie numérique',
        'Études de faisabilité terrain',
        'Bornage et délimitation',
        'Plans d\'implantation'
      ],
      image: 'https://readdy.ai/api/search-image?query=Professional%20surveying%20equipment%20on%20construction%20site%2C%20theodolite%20and%20measuring%20instruments%2C%20topographic%20survey%20work%2C%20engineers%20taking%20measurements%2C%20construction%20terrain%20analysis%2C%20precise%20measurement%20tools%2C%20outdoor%20daylight%20professional%20photography&width=600&height=400&seq=topo-service&orientation=landscape'
    },
    {
      id: 'conception',
      title: 'Conception',
      icon: 'ri-draft-line',
      description: 'Plans architecturaux et études techniques adaptés à vos besoins et contraintes.',
      details: [
        'Plans architecturaux détaillés',
        'Études structurelles',
        'Conception 3D et modélisation',
        'Plans d\'exécution',
        'Calculs de résistance',
        'Optimisation des espaces'
      ],
      image: 'https://readdy.ai/api/search-image?query=Architectural%20blueprints%20and%20design%20drawings%20on%20desk%2C%20technical%20plans%20and%20sketches%2C%20construction%20project%20planning%2C%20engineering%20design%20tools%2C%20professional%20office%20environment%2C%20detailed%20building%20plans%2C%20modern%20architectural%20workspace&width=600&height=400&seq=conception-service&orientation=landscape'
    },
    {
      id: 'devis',
      title: 'Devis',
      icon: 'ri-calculator-line',
      description: 'Estimations détaillées et transparentes pour tous vos projets de construction.',
      details: [
        'Devis détaillés par poste',
        'Évaluation des coûts matériaux',
        'Estimation main d\'œuvre',
        'Planning de réalisation',
        'Analyse comparative',
        'Suivi budgétaire'
      ],
      image: 'https://readdy.ai/api/search-image?query=Construction%20cost%20estimation%20documents%2C%20calculator%20and%20financial%20reports%2C%20budget%20planning%20for%20building%20projects%2C%20detailed%20quotation%20papers%2C%20professional%20desk%20setup%2C%20financial%20analysis%20tools%2C%20construction%20industry%20paperwork&width=600&height=400&seq=devis-service&orientation=landscape'
    },
    {
      id: 'realisation',
      title: 'Réalisation',
      icon: 'ri-hammer-line',
      description: 'Construction et mise en œuvre de vos projets avec le plus haut niveau de qualité.',
      details: [
        'Gros œuvre et structure',
        'Second œuvre complet',
        'Coordination des corps d\'état',
        'Contrôle qualité permanent',
        'Respect des délais',
        'Réception des travaux'
      ],
      image: 'https://readdy.ai/api/search-image?query=Modern%20construction%20site%20with%20workers%20building%2C%20concrete%20pouring%20and%20construction%20activities%2C%20construction%20crew%20at%20work%2C%20building%20under%20construction%2C%20construction%20equipment%20and%20materials%2C%20professional%20construction%20work%20in%20progress&width=600&height=400&seq=realisation-service&orientation=landscape'
    },
    {
      id: 'design',
      title: 'Design d\'Intérieur',
      icon: 'ri-home-4-line',
      description: 'Aménagement et décoration d\'espaces intérieurs alliant esthétique et fonctionnalité.',
      details: [
        'Conception d\'espaces intérieurs',
        'Choix des matériaux et couleurs',
        'Agencement mobilier',
        'Éclairage et ambiances',
        'Décoration personnalisée',
        'Optimisation fonctionnelle'
      ],
      image: 'https://readdy.ai/api/search-image?query=Beautiful%20modern%20interior%20design%2C%20elegant%20living%20room%20with%20contemporary%20furniture%2C%20stylish%20home%20decoration%2C%20sophisticated%20interior%20architecture%2C%20luxury%20residential%20interior%2C%20professional%20interior%20design%20showcase%2C%20ambient%20lighting&width=600&height=400&seq=design-service&orientation=landscape'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <Link href="/">
                <img 
                  src="https://static.readdy.ai/image/05dc9145483e3f0acd1651ba18bf1f9f/cd52e9b51327bdafe6e482994b87c893.jfif" 
                  alt="Innovatech Building Group" 
                  className="h-12 w-auto cursor-pointer"
                />
              </Link>
            </div>
            
            {/* Menu */}
            <div className="hidden md:flex space-x-8">
              <Link href="/" className="text-gray-600 hover:text-red-600 font-medium">Accueil</Link>
              <Link href="/services" className="text-gray-900 hover:text-red-600 font-medium">Services</Link>
              <Link href="/realisations" className="text-gray-600 hover:text-red-600 font-medium">Réalisations</Link>
              <Link href="/contact" className="text-gray-600 hover:text-red-600 font-medium">Contact</Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gray-50 py-20">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Nos Services</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Excellence et expertise dans tous vos projets de construction. Découvrez notre gamme complète de services adaptés à vos besoins.
          </p>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="space-y-20">
            {services.map((service, index) => (
              <div key={service.id} className={`grid lg:grid-cols-2 gap-16 items-center ${index % 2 === 1 ? 'lg:grid-flow-col-dense' : ''}`}>
                <div className={index % 2 === 1 ? 'lg:col-start-2' : ''}>
                  <div className="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center mb-6">
                    <i className={`${service.icon} text-2xl text-red-600`}></i>
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900 mb-4">{service.title}</h2>
                  <p className="text-lg text-gray-600 mb-8">{service.description}</p>
                  
                  <div className="grid md:grid-cols-2 gap-4 mb-8">
                    {service.details.map((detail, idx) => (
                      <div key={idx} className="flex items-center gap-3">
                        <div className="w-2 h-2 bg-red-600 rounded-full"></div>
                        <span className="text-gray-700">{detail}</span>
                      </div>
                    ))}
                  </div>
                  
                  <Link href="/contact" className="inline-flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-semibold whitespace-nowrap cursor-pointer transition-colors">
                    Demander un devis
                    <i className="ri-arrow-right-line"></i>
                  </Link>
                </div>
                
                <div className={index % 2 === 1 ? 'lg:col-start-1' : ''}>
                  <img 
                    src={service.image}
                    alt={service.title}
                    className="rounded-xl shadow-lg object-cover w-full h-96 object-top"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Notre Processus de Travail</h2>
            <p className="text-xl text-gray-600">Une approche méthodique pour garantir la réussite de vos projets</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-red-600">1</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Consultation</h3>
              <p className="text-gray-600">Analyse de vos besoins et définition du projet</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-red-600">2</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Étude</h3>
              <p className="text-gray-600">Études techniques et élaboration des plans</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-red-600">3</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Planification</h3>
              <p className="text-gray-600">Organisation des travaux et planning détaillé</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-red-600">4</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Réalisation</h3>
              <p className="text-gray-600">Exécution des travaux avec suivi qualité</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-red-600">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">Prêt à démarrer votre projet ?</h2>
          <p className="text-xl text-red-100 mb-8 max-w-2xl mx-auto">
            Contactez nos experts pour une consultation gratuite et un devis personnalisé.
          </p>
          <Link href="/contact" className="bg-white text-red-600 hover:bg-gray-100 px-8 py-4 rounded-lg font-bold text-lg whitespace-nowrap cursor-pointer transition-colors inline-block">
            Contactez-nous
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-12">
            <div>
              <img 
                src="https://static.readdy.ai/image/05dc9145483e3f0acd1651ba18bf1f9f/cd52e9b51327bdafe6e482994b87c893.jfif" 
                alt="Innovatech Building Group" 
                className="h-16 w-auto mb-4"
              />
              <p className="text-gray-400 mb-4">
                Bâtissons nos rêves - Notre engagement, votre satisfaction
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-bold mb-6">Contact</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <i className="ri-phone-line text-red-500"></i>
                  <span>+237 656 013 365</span>
                </div>
                <div className="flex items-center gap-3">
                  <i className="ri-phone-line text-red-500"></i>
                  <span>+237 673 340 009</span>
                </div>
                <div className="flex items-center gap-3">
                  <i className="ri-mail-line text-red-500"></i>
                  <span>innovatechbuildingg@gmail.com</span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-bold mb-6">Services</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Topographie & Topométrie</li>
                <li>Conception</li>
                <li>Devis</li>
                <li>Réalisation</li>
                <li>Design d\'Intérieur</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Innovatech Building Group. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
