
'use client';

import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <img 
                src="https://static.readdy.ai/image/05dc9145483e3f0acd1651ba18bf1f9f/cd52e9b51327bdafe6e482994b87c893.jfif" 
                alt="Innovatech Building Group" 
                className="h-12 w-auto"
              />
            </div>
            
            {/* Menu */}
            <div className="hidden md:flex space-x-8">
              <Link href="/" className="text-gray-900 hover:text-red-600 font-medium">Accueil</Link>
              <Link href="/services" className="text-gray-600 hover:text-red-600 font-medium">Services</Link>
              <Link href="/realisations" className="text-gray-600 hover:text-red-600 font-medium">Réalisations</Link>
              <Link href="/contact" className="text-gray-600 hover:text-red-600 font-medium">Contact</Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section 
        className="relative bg-cover bg-center h-screen flex items-center"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://readdy.ai/api/search-image?query=Modern%20construction%20site%20with%20elegant%20buildings%20under%20construction%2C%20professional%20engineering%20equipment%2C%20cranes%20and%20scaffolding%2C%20bright%20daylight%2C%20clean%20architectural%20lines%2C%20sophisticated%20urban%20development%20project%2C%20construction%20workers%20in%20safety%20gear%2C%20modern%20city%20skyline%20background%2C%20high-quality%20professional%20photography&width=1920&height=1080&seq=hero-main&orientation=landscape')`
        }}
      >
        <div className="w-full max-w-7xl mx-auto px-4">
          <div className="text-white max-w-3xl">
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              INNOVATECH<br />
              <span className="text-red-500">BUILDING GROUP</span>
            </h1>
            <p className="text-xl md:text-2xl mb-4 font-light">
              Bâtissons nos rêves
            </p>
            <p className="text-lg mb-8 opacity-90">
              Notre engagement, votre satisfaction
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/contact" className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-lg font-semibold whitespace-nowrap cursor-pointer transition-colors">
                Demander un Devis
              </Link>
              <Link href="/services" className="border-2 border-white text-white hover:bg-white hover:text-gray-900 px-8 py-3 rounded-lg font-semibold whitespace-nowrap cursor-pointer transition-colors">
                Nos Services
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Nos Services</h2>
            <p className="text-xl text-gray-600">Excellence et expertise dans tous vos projets de construction</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Topographie */}
            <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-compass-3-line text-2xl text-red-600"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Topographie & Topométrie</h3>
              <p className="text-gray-600">Relevés topographiques précis et études de terrain pour vos projets de construction.</p>
            </div>

            {/* Conception */}
            <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-draft-line text-2xl text-red-600"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Conception</h3>
              <p className="text-gray-600">Plans architecturaux et études techniques adaptés à vos besoins et contraintes.</p>
            </div>

            {/* Devis */}
            <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-calculator-line text-2xl text-red-600"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Devis</h3>
              <p className="text-gray-600">Estimations détaillées et transparentes pour tous vos projets de construction.</p>
            </div>

            {/* Réalisation */}
            <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-hammer-line text-2xl text-red-600"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Réalisation</h3>
              <p className="text-gray-600">Construction et mise en œuvre de vos projets avec le plus haut niveau de qualité.</p>
            </div>

            {/* Design d'intérieur */}
            <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-home-4-line text-2xl text-red-600"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Design d'Intérieur</h3>
              <p className="text-gray-600">Aménagement et décoration d'espaces intérieurs alliant esthétique et fonctionnalité.</p>
            </div>

            {/* Service supplémentaire */}
            <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-customer-service-2-line text-2xl text-red-600"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Suivi de Projet</h3>
              <p className="text-gray-600">Accompagnement personnalisé et suivi rigoureux de vos projets de A à Z.</p>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Innovatech Building Group</h2>
              <p className="text-lg text-gray-600 mb-6">
                Basée à Yaoundé, Innovatech Building Group est une entreprise de génie civil reconnue pour son expertise 
                et son engagement envers l'excellence. Nous accompagnons nos clients dans la réalisation de leurs projets 
                les plus ambitieux.
              </p>
              <p className="text-lg text-gray-600 mb-8">
                Notre équipe d'experts combine savoir-faire traditionnel et technologies modernes pour livrer des projets 
                qui dépassent vos attentes.
              </p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                  <i className="ri-map-pin-line text-xl text-red-600"></i>
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Direction Générale</p>
                  <p className="text-gray-600">Yaoundé, Cameroun</p>
                </div>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://readdy.ai/api/search-image?query=Professional%20construction%20team%20at%20modern%20building%20site%20in%20Yaound%C3%A9%20Cameroon%2C%20African%20engineers%20and%20architects%20reviewing%20blueprints%2C%20modern%20office%20buildings%20in%20background%2C%20professional%20business%20atmosphere%2C%20construction%20equipment%20and%20materials%2C%20bright%20daylight%2C%20high-quality%20corporate%20photography&width=600&height=500&seq=about-team&orientation=landscape"
                alt="Équipe Innovatech"
                className="rounded-xl shadow-lg object-cover w-full h-96"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-red-600">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">Prêt à concrétiser votre projet ?</h2>
          <p className="text-xl text-red-100 mb-8 max-w-2xl mx-auto">
            Contactez-nous dès aujourd'hui pour discuter de vos besoins et obtenir un devis personnalisé.
          </p>
          <Link href="/contact" className="bg-white text-red-600 hover:bg-gray-100 px-8 py-4 rounded-lg font-bold text-lg whitespace-nowrap cursor-pointer transition-colors inline-block">
            Contactez-nous
          </Link>
        </div>
      </section>

      {/* Contact Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-12">
            <div>
              <img 
                src="https://static.readdy.ai/image/05dc9145483e3f0acd1651ba18bf1f9f/cd52e9b51327bdafe6e482994b87c893.jfif" 
                alt="Innovatech Building Group" 
                className="h-16 w-auto mb-4"
              />
              <p className="text-gray-400 mb-4">
                Bâtissons nos rêves - Notre engagement, votre satisfaction
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-bold mb-6">Contact</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <i className="ri-phone-line text-red-500"></i>
                  <span>+237 656 013 365</span>
                </div>
                <div className="flex items-center gap-3">
                  <i className="ri-phone-line text-red-500"></i>
                  <span>+237 673 340 009</span>
                </div>
                <div className="flex items-center gap-3">
                  <i className="ri-mail-line text-red-500"></i>
                  <span>innovatechbuildingg@gmail.com</span>
                </div>
                <div className="flex items-center gap-3">
                  <i className="ri-map-pin-line text-red-500"></i>
                  <span>Yaoundé, Cameroun</span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-bold mb-6">Services</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Topographie & Topométrie</li>
                <li>Conception</li>
                <li>Devis</li>
                <li>Réalisation</li>
                <li>Design d'Intérieur</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Innovatech Building Group. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
